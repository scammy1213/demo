import sys
import os
import pymysql
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap, QFont, QIntValidator, QDoubleValidator
from login_form import Ui_MainWindow
from product_form_ui import Ui_ProductWindow
from product_edit import Ui_ProductEditDialog

class Database:
    def __init__(self):
        self.conn = pymysql.connect(host='MySql-8.0', user='root', password='',
                                    database='dem_DB1', cursorclass=pymysql.cursors.DictCursor)

    def get_user(self, l, p):
        with self.conn.cursor() as cur:
            cur.execute("SELECT id_user, role, full_name FROM user WHERE login=%s AND password=%s", (l, p))
            return cur.fetchone()

    def get_products(self, search='', supplier='', sort=''):
        q = "SELECT * FROM tovar WHERE 1=1"
        params = []
        if search:
            q += " AND (category LIKE %s OR description LIKE %s OR manufacturer LIKE %s OR product_name LIKE %s OR supplier LIKE %s OR unit LIKE %s)"
            like = f"%{search}%"
            params.extend([like]*6)
        if supplier and supplier != 'Все поставщики':
            q += " AND supplier=%s"
            params.append(supplier)
        q += f" ORDER BY IFNULL(stock_quantity, 0) {sort}" if sort in ('ASC','DESC') else " ORDER BY product_name"
        with self.conn.cursor() as cur:
            cur.execute(q, params)
            return cur.fetchall()

    def get_suppliers(self):
        with self.conn.cursor() as cur:
            cur.execute("SELECT DISTINCT supplier FROM tovar")
            return [r['supplier'] for r in cur.fetchall()]

    def get_categories(self):
        with self.conn.cursor() as cur:
            cur.execute("SELECT DISTINCT category FROM tovar WHERE category IS NOT NULL ORDER BY category")
            return [r['category'] for r in cur.fetchall()]

    def get_manufacturers(self):
        with self.conn.cursor() as cur:
            cur.execute("SELECT DISTINCT manufacturer FROM tovar WHERE manufacturer IS NOT NULL ORDER BY manufacturer")
            return [r['manufacturer'] for r in cur.fetchall()]

    def next_article(self):
        with self.conn.cursor() as cur:
            cur.execute("SELECT MAX(CAST(article AS UNSIGNED)) as m FROM tovar")
            return str((cur.fetchone()['m'] or 0) + 1)

    def get_product(self, art):
        with self.conn.cursor() as cur:
            cur.execute("SELECT * FROM tovar WHERE article=%s", (art,))
            return cur.fetchone()

    def save_product(self, data, edit_art=None):
        with self.conn.cursor() as cur:
            if edit_art:
                cur.execute("""UPDATE tovar SET category=%s, current_discount=%s, description=%s, image=%s,
                    manufacturer=%s, price=%s, product_name=%s, stock_quantity=%s, supplier=%s, unit=%s
                    WHERE article=%s""",
                    (data['category'], data['current_discount'], data['description'], data['image'],
                     data['manufacturer'], data['price'], data['product_name'], data['stock_quantity'],
                     data['supplier'], data['unit'], edit_art))
            else:
                cur.execute("""INSERT INTO tovar
                    (article, category, current_discount, description, image, manufacturer, price,
                     product_name, stock_quantity, supplier, unit)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (data['article'], data['category'], data['current_discount'], data['description'],
                     data['image'], data['manufacturer'], data['price'], data['product_name'],
                     data['stock_quantity'], data['supplier'], data['unit']))
            self.conn.commit()
            return True

    def delete_product(self, art):
        with self.conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) as c FROM order_items WHERE article=%s", (art,))
            if cur.fetchone()['c'] > 0:
                return False
            cur.execute("DELETE FROM tovar WHERE article=%s", (art,))
            self.conn.commit()
            return True

class ProductCard(QFrame):
    def __init__(self, prod, main_window, editable):
        super().__init__(main_window.products_container)
        self.main_window = main_window
        self.prod = prod
        self.editable = editable
        self.setFrameShape(QFrame.Box)
        self.setMinimumHeight(200)
        self.setup_ui()

    def setup_ui(self):
        layout = QHBoxLayout(self)
        img = QLabel()
        img.setFixedSize(100, 100)
        path = f"images/{self.prod['image']}" if self.prod.get('image') else "images/picture.png"
        img.setPixmap(QPixmap(path).scaled(90, 90, Qt.KeepAspectRatio))
        layout.addWidget(img)

        info = QVBoxLayout()
        price = float(self.prod['price'])
        disc = float(self.prod['current_discount'])
        title = QLabel(f"{self.prod['category']} | {self.prod['product_name']}")
        title.setFont(QFont("Times New Roman", 12, QFont.Bold))
        info.addWidget(title)
        desc = self.prod['description'][:50] + "..." if self.prod.get('description') and len(self.prod['description']) > 50 else self.prod.get('description', '')
        info.addWidget(QLabel(f"Описание: {desc}"))
        info.addWidget(QLabel(f"Производитель: {self.prod['manufacturer']}"))
        info.addWidget(QLabel(f"Поставщик: {self.prod['supplier']}"))
        if disc > 0:
            old = QLabel(f"{price:.2f} $")
            old.setStyleSheet("text-decoration:line-through;color:red")
            info.addWidget(old)
            new = QLabel(f"{price * (1 - disc / 100):.2f} $")
            new.setFont(QFont("Times New Roman", 11, QFont.Bold))
            info.addWidget(new)
        else:
            info.addWidget(QLabel(f"{price:.2f} $"))
        info.addWidget(QLabel(f"Ед.: {self.prod['unit']}  В наличии: {self.prod['stock_quantity']} шт."))
        info.addStretch()
        layout.addLayout(info)

        df = QFrame()
        df.setFixedSize(120, 100)
        df.setFrameShape(QFrame.Box)
        dl = QVBoxLayout(df)
        dl.setAlignment(Qt.AlignCenter)
        dl.addWidget(QLabel("Действующая\nскидка"))
        dl.addWidget(QLabel(f"{disc}%"))
        layout.addWidget(df)

        if disc > 15:
            self.setStyleSheet("background:#2E8B57")
        elif int(self.prod['stock_quantity']) <= 0:
            self.setStyleSheet("background:#ADD8E6")

    def mouseDoubleClickEvent(self, e):
        if self.editable:
            self.main_window.edit_requested(self.prod['article'])
        

class ProductEditDialog(QDialog, Ui_ProductEditDialog):
    def __init__(self, db, article=None, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.db = db
        self.article = article
        self.old_image = None
        self.new_image_path = None

        self.setWindowTitle("Редактирование товара" if article else "Добавление товара")
        self.setModal(True)

        self.article_edit.hide() 
        
        self.category_combo.addItems(self.db.get_categories())
        self.manufacturer_combo.addItems(self.db.get_manufacturers())
        self.unit_combo.addItems(["шт", "кг", "л", "м", "уп"])

        self.load_photo_btn.clicked.connect(self.load_photo)
        self.save_btn.clicked.connect(self.save)
        self.exit_btn.clicked.connect(self.reject)
        self.delete_btn.clicked.connect(self.delete_product)
        if not article:
            self.delete_btn.hide()

        if article:
            self.load_product_data()

    def load_photo(self):
        path, _ = QFileDialog.getOpenFileName(self, "Выберите фото", "", "Images (*.png *.jpg *.jpeg)")
        if path:
            pix = QPixmap(path)
            if pix.width() > 300 or pix.height() > 200:
                pix = pix.scaled(300, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.photo_preview.setPixmap(pix.scaled(150, 100, Qt.KeepAspectRatio))
            self.new_image_path = path

    def load_product_data(self):
        prod = self.db.get_product(self.article)
        if not prod:
            QMessageBox.warning(self, "Ошибка", "Товар не найден")
            self.reject()
            return
        self.article_edit.setText(prod['article'])
        self.name_edit.setText(prod['product_name'])
        self.category_combo.setCurrentText(prod['category'])
        self.description_edit.setPlainText(prod['description'] or '')
        self.manufacturer_combo.setCurrentText(prod['manufacturer'])
        self.supplier_edit.setText(prod['supplier'])
        self.price_edit.setValue(float(prod['price']))
        self.unit_combo.setCurrentText(prod['unit'])
        self.quantity_edit.setValue(int(prod['stock_quantity']))
        self.discount_edit.setValue(float(prod['current_discount']))
        self.old_image = prod['image']
        if prod['image'] and os.path.exists(f"images/{prod['image']}"):
            self.photo_preview.setPixmap(QPixmap(f"images/{prod['image']}").scaled(150, 100, Qt.KeepAspectRatio))
        else:
            self.photo_preview.setText("Нет фото")

    def save(self):
        if not self.name_edit.text().strip():
            QMessageBox.warning(self, "Ошибка", "Введите наименование товара")
            return
        try:
            price = self.price_edit.value()
            if price < 0: raise ValueError
            qty = self.quantity_edit.value()
            if qty < 0: raise ValueError
            disc = self.discount_edit.value()
            if disc < 0 or disc > 100: raise ValueError
        except:
            QMessageBox.warning(self, "Ошибка", "Проверьте цену (≥0), количество (целое ≥0), скидку (0-100)")
            return

        img_name = self.old_image
        if self.new_image_path:
            ext = os.path.splitext(self.new_image_path)[1]
            new_name = f"{self.article_edit.text() if self.article else self.db.next_article()}{ext}"
            os.makedirs("images", exist_ok=True)
            pix = QPixmap(self.new_image_path)
            pix = pix.scaled(300, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            pix.save(f"images/{new_name}")
            if self.old_image and self.old_image != new_name and os.path.exists(f"images/{self.old_image}"):
                os.remove(f"images/{self.old_image}")
            img_name = new_name

        data = {
            'article': self.article_edit.text() if self.article else self.db.next_article(),
            'product_name': self.name_edit.text().strip(),
            'category': self.category_combo.currentText(),
            'description': self.description_edit.toPlainText(),
            'manufacturer': self.manufacturer_combo.currentText(),
            'supplier': self.supplier_edit.text().strip(),
            'price': price,
            'unit': self.unit_combo.currentText(),
            'stock_quantity': qty,
            'current_discount': disc,
            'image': img_name
        }
        if self.db.save_product(data, self.article):
            QMessageBox.information(self, "Успех", "Данные сохранены")
            self.accept()
        else:
            QMessageBox.critical(self, "Ошибка", "Не удалось сохранить товар")

    def delete_product(self):
        reply = QMessageBox.question(self, "Удаление", "Вы уверены, что хотите удалить товар?",
                                     QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            if self.db.delete_product(self.article):
                QMessageBox.information(self, "Успех", "Товар удалён")
                self.accept()

class ProductForm(QMainWindow, Ui_ProductWindow):
    def __init__(self, user, login_win):
        super().__init__()
        self.setupUi(self)
        self.user = user
        self.login_win = login_win
        self.role = user['role']
        self.db = Database()
        self.setWindowTitle(f"{user['role']} - ООО Обувь")
        self.userlabel.setText(user['full_name'])

        is_admin_or_manager = self.role.lower() in ('менеджер', 'администратор')
        is_admin = self.role.lower() == 'администратор'

        self.add_button.setVisible(is_admin)
        self.label.setVisible(is_admin_or_manager)
        self.search_edit.setVisible(is_admin_or_manager)
        self.label_2.setVisible(is_admin_or_manager)
        self.sort_combo.setVisible(is_admin_or_manager)
        self.label_3.setVisible(is_admin_or_manager)
        self.sort_combo_2.setVisible(is_admin_or_manager)

        self.sort_combo_2.addItems(self.db.get_suppliers())
        self.sort_combo_2.currentTextChanged.connect(self.refresh)

        self.products_layout = QVBoxLayout(self.products_container)
        self.products_layout.setAlignment(Qt.AlignTop)

        self.search_edit.textChanged.connect(self.refresh)
        self.sort_combo.currentTextChanged.connect(self.refresh)
        self.logout_button.clicked.connect(self.logout)
        self.add_button.clicked.connect(self.add_product)

        self.edit_dlg = None
        self.refresh()

    def product_matches(self, product, search):
        s = search.lower()
        fields = ['product_name', 'category', 'description', 'manufacturer', 'supplier', 'unit']
        return any(s in str(product.get(f, '')).lower() for f in fields)

    def refresh(self):
        search = self.search_edit.text().strip()
        supplier = self.sort_combo_2.currentText()
        sort_text = self.sort_combo.currentText()
        sort = {"По возрастанию": "ASC", "По убыванию": "DESC"}.get(sort_text, "")
        all_products = self.db.get_products('', supplier, sort)

        if search:
            matched = [p for p in all_products if self.product_matches(p, search)]
            unmatched = [p for p in all_products if not self.product_matches(p, search)]
            products_to_show = matched + unmatched
        else:
            products_to_show = all_products

        while self.products_layout.count():
            item = self.products_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        editable = (self.role.lower() == 'администратор')
        for prod in products_to_show:
            card = ProductCard(prod, self, editable)
            self.products_layout.addWidget(card)

    def logout(self):
        self.close()
        self.login_win.show()

    def add_product(self):
        dlg = ProductEditDialog(self.db, parent=self)
        dlg.finished.connect(self.refresh)
        self.edit_dlg = dlg
        dlg.show()

    def edit_requested(self, article):
        if self.role.lower() != 'администратор':
            return
        dlg = ProductEditDialog(self.db, article, self)
        dlg.finished.connect(self.refresh)
        self.edit_dlg = dlg
        dlg.show()

class LoginForm(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.db = Database()
        self.loginButton.clicked.connect(self.on_login)
        self.guestButton.clicked.connect(self.on_guest)
        self.ExitButton.clicked.connect(self.close)

    def on_login(self):
        l = self.loginEdit.text().strip()
        p = self.passwordEdit.text().strip()
        if not l or not p:
            QMessageBox.warning(self, "Ошибка", "Введите логин и пароль")
            return
        user = self.db.get_user(l, p)
        if user:
            self.hide()
            self.product_win = ProductForm(user, self)
            self.product_win.show()
        else:
            QMessageBox.warning(self, "Ошибка", "Неверный логин или пароль")

    def on_guest(self):
        self.hide()
        guest = {'id_user': 0, 'role': 'Гость', 'full_name': 'Гость'}
        self.product_win = ProductForm(guest, self)
        self.product_win.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = LoginForm()
    win.show()
    sys.exit(app.exec())