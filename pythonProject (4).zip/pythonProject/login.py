from PySide6.QtWidgets import QApplication, QWidget, QMessageBox
from database import Database
from product_form import ProductForm
from ui.ui_login_Form import Ui_login_Form


class LoginForm(QWidget, Ui_login_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.db = Database()

        self.exit_pushButton.clicked.connect(self.exit)
        self.log_pushButton.clicked.connect(self.login)
        self.guest_pushButton.clicked.connect(self.guest)

    def login(self):
        login = self.login_lineEdit.text()
        password = self.pass_lineEdit.text()

        if not login or not password:
            QMessageBox.warning(self, "Предупреждение", "Введите логин или пароль")

        user = self.db.get_user(login, password)
        if user:
            self.open_product_form(user)
        else:
            QMessageBox.critical(self, "Ошибка", "Неверный логин или пароль")

    def guest(self):
        user = {
            'id': 0,
            'role': 'Гость',
            'full_name': 'Гость',
            'login': '',
            'password': ''
        }
        self.open_product_form(user)

    def open_product_form(self, user):
        form = ProductForm(user, self)
        self.hide()
        form.show()

    def exit(self):
        self.close()