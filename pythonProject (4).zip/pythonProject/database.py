import pymysql


class Database:
    def __init__(self):
        self.connection = None
        self.connect()

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host='MySQL-8.0',
                user='root',
                password='',
                database='dem_DB',
                cursorclass=pymysql.cursors.DictCursor
            )
        except Exception as e:
            self.connection = None

    def get_suppliers(self):
        if not self.is_connected():
            return []

        try:
            with self.connection.cursor() as c:
                c.execute("SELECT DISTINCT supplier FROM tovar")
                return c.fetchall()
        except Exception as e:
            return []

    def is_connected(self):
        return self.connection is not None

    def delete(self, article):
        try:
            with self.connection.cursor() as c:
                c.execute("SELECT COUNT(*) as cnt FROM order_items WHERE article=%s", (article,))
                result = c.fetchone()

                if result and result['cnt'] > 0:
                    return False

                c.execute("DELETE FROM tovar WHERE article=%s", (article,))
                self.connection.commit()
                return True
        except Exception as e:
            return False

    def update(self, product_data):
        try:
            with self.connection.cursor() as c:
                query = """
                UPDATE tovar
                SET name=%s, unit=%s, price=%s, supplier=%s, manufacterer=%s, category=%s, discount=%s, quantity=%s, description=%s, image=%s
                WHERE article=%s"""
                c.execute(query, (product_data['name'], product_data['unit'],
                                  product_data['price'], product_data['supplier'], product_data['manufacterer'],
                                  product_data['category'], product_data['discount'], product_data['quantity'],
                                  product_data['description'], product_data['image'], product_data['article']))
                self.connection.commit()
                return True
        except Exception as e:
            return False

    def add(self, product_data):
        try:
            with self.connection.cursor() as c:
                query = """
                INSERT INTO tovar
                (article, name, unit, price, supplier, manufacterer, category, discount, quantity, description, image)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                c.execute(query, (product_data['article'], product_data['name'], product_data['unit'],
                                  product_data['price'], product_data['supplier'], product_data['manufacterer'],
                                  product_data['category'], product_data['discount'], product_data['quantity'],
                                  product_data['description'], product_data['image']))
                self.connection.commit()
                return True
        except Exception as e:
            return False

    def get_product(self, sort_type=None, search_text=None, supp=None):
        if not self.is_connected():
            return []

        conditions = []
        params = []

        order_by = "name ASC"
        if supp == "Все поставщики":
            supp = None

        if sort_type == 1:
            order_by = "price ASC"
        if sort_type == 2:
            order_by = "price DESC"
        if sort_type == 3:
            order_by = "discount ASC"
        if sort_type == 4:
            order_by = "quantity ASC"

        try:
            with self.connection.cursor() as cursor:
                query = "SELECT * FROM tovar"
                if search_text:
                    conditions.append("name LIKE %s")
                    params.append(f"%{search_text}%")
                if supp:
                    conditions.append("supplier LIKE %s")
                    params.append(f"%{supp}%")
                if conditions:
                    where = " WHERE " + " AND ".join(conditions)
                    query = query + where
                query = query + f" ORDER BY {order_by}"
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                return cursor.fetchall()
        except Exception as e:
            print(e)
            return []

    def get_user(self, login, password):
        try:
            with self.connection.cursor() as cursor:
                query = "SELECT id, role, full_name FROM user WHERE login=%s AND password=%s"
                cursor.execute(query, (login, password))
                result = cursor.fetchone()
                return result
        except Exception as e:
            return None

    def close(self):
        self.connection.close()
        self.connection = None