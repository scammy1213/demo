# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'login_FormAAklVg.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_login_Form(object):
    def setupUi(self, login_Form):
        if not login_Form.objectName():
            login_Form.setObjectName(u"login_Form")
        login_Form.resize(785, 521)
        font = QFont()
        font.setFamilies([u"Times New Roman"])
        font.setPointSize(12)
        login_Form.setFont(font)
        login_Form.setStyleSheet(u"background-color:white;")
        self.verticalLayout = QVBoxLayout(login_Form)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.exit_pushButton = QPushButton(login_Form)
        self.exit_pushButton.setObjectName(u"exit_pushButton")

        self.horizontalLayout.addWidget(self.exit_pushButton)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_2)

        self.label = QLabel(login_Form)
        self.label.setObjectName(u"label")
        self.label.setMaximumSize(QSize(100, 100))
        self.label.setPixmap(QPixmap(u"./Icon.png"))
        self.label.setScaledContents(True)

        self.horizontalLayout_2.addWidget(self.label)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_3)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalSpacer_4 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_4)

        self.label_2 = QLabel(login_Form)
        self.label_2.setObjectName(u"label_2")

        self.horizontalLayout_3.addWidget(self.label_2)

        self.login_lineEdit = QLineEdit(login_Form)
        self.login_lineEdit.setObjectName(u"login_lineEdit")

        self.horizontalLayout_3.addWidget(self.login_lineEdit)

        self.horizontalSpacer_6 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_6)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_5)

        self.label_3 = QLabel(login_Form)
        self.label_3.setObjectName(u"label_3")

        self.horizontalLayout_4.addWidget(self.label_3)

        self.pass_lineEdit = QLineEdit(login_Form)
        self.pass_lineEdit.setObjectName(u"pass_lineEdit")
        self.pass_lineEdit.setEchoMode(QLineEdit.EchoMode.Password)
        self.pass_lineEdit.setReadOnly(False)

        self.horizontalLayout_4.addWidget(self.pass_lineEdit)

        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_7)


        self.verticalLayout.addLayout(self.horizontalLayout_4)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_8)

        self.guest_pushButton = QPushButton(login_Form)
        self.guest_pushButton.setObjectName(u"guest_pushButton")

        self.horizontalLayout_5.addWidget(self.guest_pushButton)

        self.log_pushButton = QPushButton(login_Form)
        self.log_pushButton.setObjectName(u"log_pushButton")

        self.horizontalLayout_5.addWidget(self.log_pushButton)

        self.horizontalSpacer_9 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_9)


        self.verticalLayout.addLayout(self.horizontalLayout_5)


        self.retranslateUi(login_Form)

        QMetaObject.connectSlotsByName(login_Form)
    # setupUi

    def retranslateUi(self, login_Form):
        login_Form.setWindowTitle(QCoreApplication.translate("login_Form", u"\u041e\u043a\u043d\u043e \u0430\u0432\u0442\u043e\u0440\u0438\u0437\u0430\u0446\u0438\u0438 - \u041e\u041e\u041e \u041e\u0431\u0443\u0432\u044c", None))
        self.exit_pushButton.setText(QCoreApplication.translate("login_Form", u"\u0412\u044b\u0445\u043e\u0434", None))
        self.label.setText("")
        self.label_2.setText(QCoreApplication.translate("login_Form", u"\u041b\u043e\u0433\u0438\u043d:", None))
        self.login_lineEdit.setPlaceholderText(QCoreApplication.translate("login_Form", u"\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043b\u043e\u0433\u0438\u043d...", None))
        self.label_3.setText(QCoreApplication.translate("login_Form", u"\u041f\u0430\u0440\u043e\u043b\u044c:", None))
        self.pass_lineEdit.setPlaceholderText(QCoreApplication.translate("login_Form", u"\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043f\u0430\u0440\u043e\u043b\u044c...", None))
        self.guest_pushButton.setText(QCoreApplication.translate("login_Form", u"\u0412\u043e\u0439\u0442\u0438 \u043a\u0430\u043a \u0433\u043e\u0441\u0442\u044c", None))
        self.log_pushButton.setText(QCoreApplication.translate("login_Form", u"\u0412\u043e\u0439\u0442\u0438", None))
    # retranslateUi

