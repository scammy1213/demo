# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'product_FormVgzxGF.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QScrollArea, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

class Ui_product_Form(object):
    def setupUi(self, product_Form):
        if not product_Form.objectName():
            product_Form.setObjectName(u"product_Form")
        product_Form.resize(852, 522)
        font = QFont()
        font.setFamilies([u"Times New Roman"])
        font.setPointSize(12)
        product_Form.setFont(font)
        self.verticalLayout = QVBoxLayout(product_Form)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.full_name_label = QLabel(product_Form)
        self.full_name_label.setObjectName(u"full_name_label")

        self.horizontalLayout.addWidget(self.full_name_label)

        self.exit_pushButton = QPushButton(product_Form)
        self.exit_pushButton.setObjectName(u"exit_pushButton")

        self.horizontalLayout.addWidget(self.exit_pushButton)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.add_pushButton = QPushButton(product_Form)
        self.add_pushButton.setObjectName(u"add_pushButton")

        self.horizontalLayout_2.addWidget(self.add_pushButton)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_2)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.search_label = QLabel(product_Form)
        self.search_label.setObjectName(u"search_label")

        self.horizontalLayout_3.addWidget(self.search_label)

        self.search_lineEdit = QLineEdit(product_Form)
        self.search_lineEdit.setObjectName(u"search_lineEdit")

        self.horizontalLayout_3.addWidget(self.search_lineEdit)

        self.sort_label = QLabel(product_Form)
        self.sort_label.setObjectName(u"sort_label")

        self.horizontalLayout_3.addWidget(self.sort_label)

        self.sort_comboBox = QComboBox(product_Form)
        self.sort_comboBox.addItem("")
        self.sort_comboBox.addItem("")
        self.sort_comboBox.addItem("")
        self.sort_comboBox.addItem("")
        self.sort_comboBox.addItem("")
        self.sort_comboBox.setObjectName(u"sort_comboBox")
        self.sort_comboBox.setMinimumSize(QSize(150, 0))

        self.horizontalLayout_3.addWidget(self.sort_comboBox)

        self.label = QLabel(product_Form)
        self.label.setObjectName(u"label")

        self.horizontalLayout_3.addWidget(self.label)

        self.supp_comboBox = QComboBox(product_Form)
        self.supp_comboBox.addItem("")
        self.supp_comboBox.setObjectName(u"supp_comboBox")
        self.supp_comboBox.setMinimumSize(QSize(170, 0))

        self.horizontalLayout_3.addWidget(self.supp_comboBox)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_3)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.scrollArea = QScrollArea(product_Form)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 830, 395))
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)

        self.verticalLayout.addWidget(self.scrollArea)


        self.retranslateUi(product_Form)

        QMetaObject.connectSlotsByName(product_Form)
    # setupUi

    def retranslateUi(self, product_Form):
        product_Form.setWindowTitle(QCoreApplication.translate("product_Form", u"\u041e\u043a\u043d\u043e \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u044f \u0442\u043e\u0432\u0430\u0440\u0430\u043c\u0438 - \u041e\u041e\u041e \u041e\u0431\u0443\u0432\u044c", None))
        self.full_name_label.setText(QCoreApplication.translate("product_Form", u"\u0424\u0418\u041e \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044f", None))
        self.exit_pushButton.setText(QCoreApplication.translate("product_Form", u"\u0412\u044b\u0445\u043e\u0434", None))
        self.add_pushButton.setText(QCoreApplication.translate("product_Form", u"\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0442\u043e\u0432\u0430\u0440", None))
        self.search_label.setText(QCoreApplication.translate("product_Form", u"\u041f\u043e\u0438\u0441\u043a:", None))
        self.search_lineEdit.setPlaceholderText(QCoreApplication.translate("product_Form", u"\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0442\u0435\u043a\u0441\u0442...", None))
        self.sort_label.setText(QCoreApplication.translate("product_Form", u"\u0421\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u043a\u0430:", None))
        self.sort_comboBox.setItemText(0, QCoreApplication.translate("product_Form", u"\u041f\u043e \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044e", None))
        self.sort_comboBox.setItemText(1, QCoreApplication.translate("product_Form", u"\u041f\u043e \u0446\u0435\u043d\u0435 (\u0432\u043e\u0437\u0440.)", None))
        self.sort_comboBox.setItemText(2, QCoreApplication.translate("product_Form", u"\u041f\u043e \u0446\u0435\u043d\u0435(\u0443\u0431\u044b\u0432.)", None))
        self.sort_comboBox.setItemText(3, QCoreApplication.translate("product_Form", u"\u041f\u043e \u0441\u043a\u0438\u0434\u043a\u0435", None))
        self.sort_comboBox.setItemText(4, QCoreApplication.translate("product_Form", u"\u041f\u043e \u043a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u0443", None))

        self.label.setText(QCoreApplication.translate("product_Form", u"\u041f\u043e\u0441\u0442\u0430\u0432\u0449\u0438\u043a\u0438:", None))
        self.supp_comboBox.setItemText(0, QCoreApplication.translate("product_Form", u"\u0412\u0441\u0435 \u043f\u043e\u0441\u0442\u0430\u0432\u0449\u0438\u043a\u0438", None))

    # retranslateUi

