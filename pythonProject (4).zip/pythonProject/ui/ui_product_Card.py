# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'product_CardKWqhgm.ui'
##
## Created by: Qt User Interface Compiler version 6.11.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QPushButton, QSizePolicy, QVBoxLayout, QWidget)

class Ui_product_Card(object):
    def setupUi(self, product_Card):
        if not product_Card.objectName():
            product_Card.setObjectName(u"product_Card")
        product_Card.resize(926, 366)
        product_Card.setMinimumSize(QSize(0, 200))
        product_Card.setMaximumSize(QSize(16777215, 400))
        font = QFont()
        font.setFamilies([u"Times New Roman"])
        font.setPointSize(12)
        product_Card.setFont(font)
        product_Card.setStyleSheet(u"")
        self.horizontalLayout = QHBoxLayout(product_Card)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.frame = QFrame(product_Card)
        self.frame.setObjectName(u"frame")
        self.frame.setStyleSheet(u"")
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.img_label = QLabel(self.frame)
        self.img_label.setObjectName(u"img_label")
        self.img_label.setMaximumSize(QSize(100, 100))
        self.img_label.setScaledContents(True)

        self.horizontalLayout_2.addWidget(self.img_label)


        self.horizontalLayout_3.addLayout(self.horizontalLayout_2)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.name_label = QLabel(self.frame)
        self.name_label.setObjectName(u"name_label")
        font1 = QFont()
        font1.setFamilies([u"Times New Roman"])
        font1.setPointSize(22)
        font1.setBold(True)
        self.name_label.setFont(font1)

        self.verticalLayout.addWidget(self.name_label)

        self.descr_label = QLabel(self.frame)
        self.descr_label.setObjectName(u"descr_label")

        self.verticalLayout.addWidget(self.descr_label)

        self.manu_label = QLabel(self.frame)
        self.manu_label.setObjectName(u"manu_label")

        self.verticalLayout.addWidget(self.manu_label)

        self.supp_label = QLabel(self.frame)
        self.supp_label.setObjectName(u"supp_label")

        self.verticalLayout.addWidget(self.supp_label)

        self.old_label = QLabel(self.frame)
        self.old_label.setObjectName(u"old_label")
        self.old_label.setStyleSheet(u"text-decoration: line-through;\n"
"color:red;")

        self.verticalLayout.addWidget(self.old_label)

        self.new_label = QLabel(self.frame)
        self.new_label.setObjectName(u"new_label")
        font2 = QFont()
        font2.setFamilies([u"Times New Roman"])
        font2.setPointSize(12)
        font2.setBold(True)
        self.new_label.setFont(font2)

        self.verticalLayout.addWidget(self.new_label)

        self.un_qua_label = QLabel(self.frame)
        self.un_qua_label.setObjectName(u"un_qua_label")

        self.verticalLayout.addWidget(self.un_qua_label)


        self.horizontalLayout_3.addLayout(self.verticalLayout)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        self.label.setMinimumSize(QSize(120, 80))
        self.label.setMaximumSize(QSize(120, 80))
        self.label.setSizeIncrement(QSize(0, 0))
        self.label.setFont(font2)
        self.label.setStyleSheet(u"border: 1px solid black;")
        self.label.setTextFormat(Qt.TextFormat.AutoText)
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_2.addWidget(self.label)


        self.horizontalLayout_3.addLayout(self.verticalLayout_2)

        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.upd_pushButton = QPushButton(self.frame)
        self.upd_pushButton.setObjectName(u"upd_pushButton")
        sizePolicy.setHeightForWidth(self.upd_pushButton.sizePolicy().hasHeightForWidth())
        self.upd_pushButton.setSizePolicy(sizePolicy)

        self.verticalLayout_3.addWidget(self.upd_pushButton)

        self.del_pushButton = QPushButton(self.frame)
        self.del_pushButton.setObjectName(u"del_pushButton")
        sizePolicy.setHeightForWidth(self.del_pushButton.sizePolicy().hasHeightForWidth())
        self.del_pushButton.setSizePolicy(sizePolicy)

        self.verticalLayout_3.addWidget(self.del_pushButton)


        self.horizontalLayout_3.addLayout(self.verticalLayout_3)


        self.horizontalLayout.addWidget(self.frame)


        self.retranslateUi(product_Card)

        QMetaObject.connectSlotsByName(product_Card)
    # setupUi

    def retranslateUi(self, product_Card):
        product_Card.setWindowTitle(QCoreApplication.translate("product_Card", u"Form", None))
        self.img_label.setText("")
        self.name_label.setText(QCoreApplication.translate("product_Card", u"TextLabel", None))
        self.descr_label.setText(QCoreApplication.translate("product_Card", u"TextLabel", None))
        self.manu_label.setText(QCoreApplication.translate("product_Card", u"TextLabel", None))
        self.supp_label.setText(QCoreApplication.translate("product_Card", u"TextLabel", None))
        self.old_label.setText(QCoreApplication.translate("product_Card", u"TextLabel", None))
        self.new_label.setText(QCoreApplication.translate("product_Card", u"TextLabel", None))
        self.un_qua_label.setText(QCoreApplication.translate("product_Card", u"TextLabel", None))
        self.label.setText(QCoreApplication.translate("product_Card", u"<html><head/><body><p>\u0414\u0435\u0439\u0441\u0442\u0432\u0443\u044e\u0449\u0430\u044f</p><p>\u0441\u043a\u0438\u0434\u043a\u0430</p></body></html>", None))
        self.upd_pushButton.setText(QCoreApplication.translate("product_Card", u"\u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c", None))
        self.del_pushButton.setText(QCoreApplication.translate("product_Card", u"\u0423\u0434\u0430\u043b\u0438\u0442\u044c", None))
    # retranslateUi

