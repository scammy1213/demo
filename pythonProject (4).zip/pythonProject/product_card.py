from PySide6.QtWidgets import QWidget, QDialog, QMessageBox
from PySide6.QtGui import QPixmap
from product_dialog import ProductDialog
from database import Database
from ui.ui_product_Card import Ui_product_Card


class ProductCard(QWidget, Ui_product_Card):
    def __init__(self, product_data, parent=None, db=None):
        super().__init__()
        self.setupUi(self)
        self.prnt = parent
        self.product = product_data
        self.db = db
        self.fill_data()
        self.apply_styles()

        self.upd_pushButton.clicked.connect(self.edit)
        self.del_pushButton.clicked.connect(self.delete)

    def fill_data(self):
        img_path = f"images/{self.product['image']}" if self.product.get('image') else "images/picture.png"
        pixmap = QPixmap(img_path)
        self.img_label.setPixmap(pixmap)
        self.name_label.setText(self.product['name'])
        desc = self.product['description']
        if len(desc) > 50:
            desc = desc[:50] + "..."
        self.descr_label.setText(desc)
        self.manu_label.setText(self.product['manufacterer'])
        self.supp_label.setText(self.product['supplier'])
        discount = float(self.product['discount'])
        price = float(self.product['price'])
        if discount > 0:
            self.old_label.setText(f"{price:.2f}")
            new_price = price - price / 100 * discount
            self.new_label.setText(f"{new_price:.2f}")
        else:
            self.old_label.setVisible(0)
            self.new_label.setText(f"{price:.2f}")
        self.un_qua_label.setText(f"{self.product['unit']}, {self.product['quantity']}")
        self.label.setText(f"Действующая\nскидка\n{discount}%")

    def apply_styles(self):
        discount = float(self.product['discount'])
        quantity = int(self.product['quantity'])
        if discount > 15:
            self.frame.setStyleSheet("background-color: green;")
        if quantity <= 0:
            self.frame.setStyleSheet("background-color: blue;")

    def delete(self):
        reply = QMessageBox.question(
            self,
            "Подтверждение удаления",
            f"Удалить товар {self.product['name']}?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            article = self.product['article']
            success = self.db.delete(article)

            if success:
                if self.prnt:
                    self.prnt.load_products()

    def edit(self):
        dialog = ProductDialog(self.product, self.prnt)

        if dialog.exec() == QDialog.Accepted:
            new_data = dialog.get_product()

            if self.db.update(new_data):
                self.product = new_data
                self.fill_data()
                self.apply_styles()