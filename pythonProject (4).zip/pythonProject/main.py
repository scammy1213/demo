import sys
from PySide6.QtWidgets import QApplication
from login import LoginForm


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LoginForm()
    window.show()
    sys.exit(app.exec())