from PySide6.QtWidgets import QWidget, QVBoxLayout, QDialog, QMessageBox
from database import Database
from product_card import ProductCard
from product_dialog import ProductDialog
from ui.ui_product_Form import Ui_product_Form


class ProductForm(QWidget, Ui_product_Form):
    def __init__(self, user, parent=None):
        super().__init__()
        self.setupUi(self)

        self.user = user
        self.role = user['role']
        self.user_name = user['full_name']
        self.parent = parent
        self.db = Database()
        self.full_name_label.setText(self.user_name)

        self.scroll_layout = QVBoxLayout(self.scrollAreaWidgetContents)
        self.scrollAreaWidgetContents.setLayout(self.scroll_layout)

        self.sort_comboBox.currentIndexChanged.connect(self.on_changed)
        self.search_lineEdit.textChanged.connect(self.on_changed)
        self.supp_comboBox.currentIndexChanged.connect(self.on_changed)
        self.add_pushButton.clicked.connect(self.on_add)
        self.exit_pushButton.clicked.connect(self.exit)

        self.load_supp()
        self.load_products()

    def exit(self):
        self.parent.show()
        self.close()

    def load_supp(self):
        supp = self.db.get_suppliers()
        for s in supp:
            self.supp_comboBox.addItem(s['supplier'])

    def on_changed(self):
        search_text = self.search_lineEdit.text().strip()
        sort_type = self.sort_comboBox.currentIndex()
        supp = self.supp_comboBox.currentText().strip()

        self.load_products(sort_type, search_text, supp)

    def load_products(self, sort_type=None, search_text=None, supp=None):
        product_data = self.db.get_product(sort_type, search_text, supp)
        while self.scroll_layout.count():
            item = self.scroll_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        for p in product_data:
            card = ProductCard(p, self, self.db)
            self.scroll_layout.addWidget(card)

    def on_add(self):
        dialog = ProductDialog(None, self)
        if dialog.exec() == QDialog.Accepted:
            product_data = dialog.get_product()

            if not product_data['article']:
                QMessageBox.warning(self, "Ошибка", "Арктикул обязателен")
                return
            if not product_data['name']:
                QMessageBox.warning(self, "Ошибка", "Название обязателен")
                return

            existing = self.db.get_product()
            articles = [p['article'] for p in existing]
            if product_data['article'] in articles:
                QMessageBox.warning(self, "Ошибка", "Арктикул существует")
                return
            if self.db.add(product_data):
                QMessageBox.information(self, "Успех", f"Товар {product_data['name']} добавлен")
                self.load_products()
            else:
                QMessageBox.warning(self, "Ошибка", "Не удалось")