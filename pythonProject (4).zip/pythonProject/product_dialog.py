import os.path

from PySide6.QtWidgets import QDialog, QFileDialog
from PySide6.QtGui import QPixmap, QImage
from ui.ui_product_Dialog import Ui_Dialog


class ProductDialog(QDialog, Ui_Dialog):
    def __init__(self, product_data=None, parent=None):
        super().__init__()
        self.setupUi(self)

        self.product_data = product_data
        self.parent = parent

        self.setWindowTitle("Добавление товара" if self.product_data is None else "Редактирование товара")

        self.orig_img = None
        self.temp_img = None

        self.img_lineEdit.setReadOnly(True)

        self.browse_image_button.clicked.connect(self.select_image)
        self.buttonBox.accepted.connect(self.accept)
        self.buttonBox.rejected.connect(self.reject)

        if product_data:
            self.load_product()
            self.article_lineEdit.setReadOnly(True)

    def select_image(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Выберите изображение",
                                                   "", "Изображение (*.png, *.jpg)")
        img = QImage(file_path)
        if img.isNull():
            return
        self.temp_img = file_path
        pixmap = QPixmap(file_path)
        self.preview_label.setPixmap(pixmap)
        self.temp_img = file_path
        self.img_lineEdit.setText(os.path.basename(file_path))

    def save_image(self):
        os.makedirs("images", exist_ok=True)

        img = QImage(self.temp_img)
        img = img.scaled(300, 200)
        img.save(os.path.join("images", os.path.basename(self.temp_img)))
        old_path = os.path.join("images", self.product_data['image'])
        if os.path.exists(old_path) and self.product_data['image']:
            os.remove(old_path)
        return self.img_lineEdit.text()

    def load_product(self):
        self.article_lineEdit.setText(self.product_data['article'])
        self.desc_lineEdit.setText(self.product_data['description'])
        self.cat_lineEdit.setText(self.product_data['category'])
        self.name_lineEdit.setText(self.product_data['name'])
        self.unit_lineEdit.setText(self.product_data['unit'])
        self.supp_lineEdit.setText(self.product_data['supplier'])
        self.manu_lineEdit.setText(self.product_data['manufacterer'])
        self.img_lineEdit.setText(self.product_data['image'])
        self.price_doubleSpinBox.setValue(self.product_data['price'])
        self.disc_doubleSpinBox.setValue(self.product_data['discount'])
        self.qua_spinBox.setValue(self.product_data['quantity'])

        img_path = self.product_data["image"]
        if img_path:
            self.preview_label.setPixmap(QPixmap(f"images/{img_path}"))
        else:
            self.preview_label.setPixmap(QPixmap("images/picture.png"))

    def get_product(self):
        if self.temp_img:
            img = self.save_image()
        else:
            img = self.product_data["image"]
        return {
            'article': self.article_lineEdit.text().strip(),
            'description': self.desc_lineEdit.text().strip(),
            'category': self.cat_lineEdit.text().strip(),
            'name': self.name_lineEdit.text().strip(),
            'unit': self.unit_lineEdit.text().strip(),
            'supplier': self.supp_lineEdit.text().strip(),
            'manufacterer': self.manu_lineEdit.text().strip(),
            'image': img,
            'price': self.price_doubleSpinBox.value(),
            'discount': self.disc_doubleSpinBox.value(),
            'quantity': self.qua_spinBox.value(),
        }